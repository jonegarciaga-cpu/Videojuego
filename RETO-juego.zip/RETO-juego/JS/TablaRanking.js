window.addEventListener("load", () => {
    const datos = getRankingUsers().map(r => ({
        usuario: r.Usuario,
        personaje: r.Nombre,
        imagen: r.Imagen,
        fechaHora: new Date(r.FechaHora),
        puntuacion: r.Puntuacion
    }));

    generarTabla(datos); 
    document.getElementById("reiniciar").addEventListener("click", reiniciarTabla);
})


function generarTabla(datos) {
    datos.sort((a, b) => b.puntuacion - a.puntuacion);

    let tabla = document.createElement("table");

    let header = document.createElement("thead");
    let filaHeader = document.createElement("tr");
    const titulos = ["Pos.", "Usuario", "Personaje", "Imagen", "Fecha y Hora", "Rondas"];

    titulos.forEach(titulo => {
        let th = document.createElement("th");
        th.textContent = titulo;
        filaHeader.appendChild(th);
    });

    header.appendChild(filaHeader);
    tabla.appendChild(header);

    for (let j = 0; j < 10 && j < datos.length; j++) {
        let fila = document.createElement("tr");
        let th = document.createElement("th");
        th.textContent = (j + 1) + "-";
        fila.appendChild(th);

        let fecha = datos[j].fechaHora;
        let dia = fecha.getDate().toString().padStart(2, '0');
        let mes = (fecha.getMonth() + 1).toString().padStart(2, '0');
        let anio = fecha.getFullYear();
        let hora = fecha.getHours().toString().padStart(2, '0');
        let minutos = fecha.getMinutes().toString().padStart(2, '0');

        let fechaFormateada = `${dia}/${mes}/${anio} ${hora}:${minutos}`;

        let columnas = [
            datos[j].usuario,
            datos[j].personaje,
            datos[j].imagen,
            fechaFormateada,
            datos[j].puntuacion
        ];

        columnas.forEach((valor, indice) => {
            let td = document.createElement("td");

            if (indice === 2) {
                let img = document.createElement("img");
                img.src = valor;
                img.alt = datos[j].personaje;
                img.width = 60;
                img.height = 60;
                td.appendChild(img);
            } else {
                td.textContent = valor;
            }

            fila.appendChild(td);
        });
        tabla.appendChild(fila);
    }

    document.querySelector(".container_Tabla").appendChild(tabla);

}


function reiniciarTabla() {
    let filasDatos = document.querySelectorAll(".container_Tabla table tr:not(thead tr)");
    for (let i = 0; i < filasDatos.length; i++) {
        filasDatos[i].remove();
    }
    removeRanking();
}
