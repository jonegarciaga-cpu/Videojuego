var loginButton = document.getElementById("logIn");

var completeUser = new URLSearchParams(window.location.search);
if (completeUser.get("userName")) {
    document.getElementById("userName").value = completeUser.get("userName");
    document.getElementById("userPass").focus();
}

loginButton.addEventListener("click", function (e) {
    e.preventDefault();
    var userName = document.getElementById("userName").value;
    var userPass = document.getElementById("userPass").value;

    var user = findUser(userName);

    if (user && user.Contraseña === userPass) {
        var sessionUser = {
            Nombre: user.Nombre,
            FechaNacimiento: user.FechaNacimiento,
            Genero: user.Genero,
            Existes: user.Existes
        };
        saveSession(sessionUser);
        window.location.href = "./HTML/perfil.html";
    } else {
        alert("Usuario o contraseña incorrectos.");
    }
});