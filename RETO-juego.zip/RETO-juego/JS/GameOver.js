window.addEventListener("load", () => {
    const usuario = UsuarioCargado();
    const personaje = JSON.parse(sessionStorage.getItem("personajeElegido"));

    const nusuario = (usuario && usuario.Nombre) ? usuario.Nombre : "valiente sin nombre";
    const npersonaje = (personaje && personaje.Nombre) ? personaje.Nombre : "un héroe anónimo";
    const nivel = (personaje && personaje.Nivel) ? personaje.Nivel : 0;

    textos(nusuario, npersonaje, nivel);
    console.log(personaje);
    const mantener = document.getElementById("mantener_GO");
    const eliminar = document.getElementById("eliminar_GO");

    mantener.addEventListener("click", function () {
        updateCharacter(resetearPersonaje(personaje));
        window.opener.location.href = "./perfil.html"; window.close();
    });

    eliminar.addEventListener("click", function () {
        deleteCharacterUser(personaje);
        window.opener.location.href = "./perfil.html"; window.close();

    });
});

function resetearPersonaje(personaje) {
    personaje.Nivel = 1;
    personaje.Fuerza = 10;
    personaje.Sabiduria = 10;
    personaje.Defensa = 10;
    personaje.Vida = 120;
    return personaje;
}
function textos(nusuario, npersonaje, nivel) {
    const texto = document.getElementById("testo_Derrota");
    if (!texto) return;

    if (nivel >= 10) {
        texto.textContent = textoVictoria(nusuario, npersonaje, nivel);
    } else {
        texto.textContent = textoDerrota(nusuario, npersonaje);
    }
}

function textoDerrota(nusuario, npersonaje) {
    return "⚔️ ¡Escucha, " + nusuario + "!\n\n" +
        "Las crónicas de " + npersonaje + " han llegado a su fin. " +
        "El destino te ofrece dos caminos:\n\n" +
        "¿Reiniciarás su leyenda desde el principio (nivel 1), " +
        "para que su nombre vuelva a resonar en las tierras del reino?\n\n" +
        "¿O preferirás borrar su nombre de las crónicas de tu gremio para siempre?\n\n" +
        "Elige con sabiduría, héroe.";
}

function textoVictoria(nusuario, npersonaje, nivel) {
    return "🏆 ¡Gloria eterna, " + nusuario + "!\n\n" +
        "Las hazañas de " + npersonaje + " han sido grabadas en piedra. " +
        "Con " + nivel + " niveles de valentía, " +
        "su nombre ya resuena en cada rincón del reino.\n\n" +
        "Los bardos cantarán esta gesta durante mil lunas.\n\n" +
        "¿Reiniciarás la leyenda para forjar una nueva, " +
        "aún más gloriosa desde el nivel 1?\n\n" +
        "¿O dejarás que su nombre permanezca grabado en las crónicas del gremio?\n\n" +
        "El destino aguarda tu sentencia, campeón.";
}   