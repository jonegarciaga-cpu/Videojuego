var signinButton = document.getElementById("signIn");

signinButton.addEventListener("click", function (e) {
    e.preventDefault();
    var userName = document.getElementById("userName").value;
    var userPass = document.getElementById("userPass").value;
    var userBirthdate = document.getElementById("userBirthdate").value;
    var userGender = document.querySelector('input[name="userGender"]:checked').value;
    var userPlayed = document.getElementById("userPlayed").checked;

    if (!checkUserName(userName)) {
        alert("El usuario debe tener entre 8 y 16 caracteres.");
    } else if (!checkUserPass(userPass)) {
        alert("La contraseña debe tener 9 caracteres alfanuméricos.");
    } else if (findUser(userName)) {
        alert("Ese nombre de usuario ya existe.");
    } else {
        var newUsuario = new User(userName, userPass, userBirthdate, userGender, userPlayed);
        addUser(newUsuario);
        window.location.href = "../index.html?userName=" + encodeURIComponent(userName);
    }
});

function checkUserName(userName) {
    return userName.length > 7 && userName.length < 17;
}

function checkUserPass(userPass) {
    var regex = /^[0-9A-Za-z]{9}$/;
    return regex.test(userPass);
}