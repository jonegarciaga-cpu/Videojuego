var SESSION_KEY = "currentUser";

function saveSession(user) {
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(user));
}

function getSession() {
    var user = sessionStorage.getItem(SESSION_KEY);
    return user ? JSON.parse(user) : null;
}

function closeSession() {
    sessionStorage.removeItem(SESSION_KEY);
}