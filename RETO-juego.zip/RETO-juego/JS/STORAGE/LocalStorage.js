var LOCAL_KEY = "users";
var CHAR_KEY = "characters";
var RANKING_KEY = "ranking";

function getUsers() {
    var users = localStorage.getItem(LOCAL_KEY);
    if (!users) {
        return [];
    }
    return JSON.parse(users).map(obj => User.fromJSON(obj));
}

function addUser(newUser) {
    var userList = getUsers();
    userList.push(newUser);
    localStorage.setItem(LOCAL_KEY, JSON.stringify(userList));
}

function addCharacter(newCharacter) {
    var characterList = getCharacters();
    characterList.push(newCharacter);
    localStorage.setItem(CHAR_KEY, JSON.stringify(characterList));
}

function addUsers(newUsers) {
    localStorage.setItem(LOCAL_KEY, JSON.stringify(newUsers));
}

function findUser(nombre) {
    return getUsers().find(user => user.Nombre === nombre);
}

function removeUsers() {
    localStorage.removeItem(LOCAL_KEY);
}

function updateUserName(nombreAntiguo, nuevoNombre) {
    var users = getUsers();
    var user = users.find(u => u.Nombre === nombreAntiguo);
    if (!user) return false;

    user.Nombre = nuevoNombre;
    localStorage.setItem(LOCAL_KEY, JSON.stringify(users));
    return true;
}

function getCharacters() {
    var character = localStorage.getItem(CHAR_KEY);
    if (!character) {
        return [];
    }
    return JSON.parse(character).map(obj => Personaje.fromJSON(obj));
}
function getSelectedCharacter() {
    const personajeJSON = localStorage.getItem("personajeSeleccionado");
    if (!personajeJSON || personajeJSON === "undefined") {
        return null;
    }

    const personajePlano = JSON.parse(personajeJSON);
    const nombreBuscado = personajePlano.Nombre || personajePlano._Nombre;
    let resultado = personajePlano;

    const listaJSON = localStorage.getItem("characters");
    if (listaJSON) {
        const listaPersonajes = JSON.parse(listaJSON);
        const personajeActualizado = listaPersonajes.find(p => {
            if (!p) return false;
            const nombreEnLista = p.Nombre || p._Nombre;
            return nombreEnLista === nombreBuscado;
        });

        if (personajeActualizado) {
            resultado = personajeActualizado;
        }
    }

    return resultado;
}

function updateCharacter(personajeActualizado) {
    const imagenDestino = personajeActualizado.Imagen || personajeActualizado._Imagen;
    personajeActualizado.Imagen = imagenDestino;
    personajeActualizado._Imagen = imagenDestino;

    if (personajeActualizado.Vida !== undefined) personajeActualizado.Vida = parseInt(personajeActualizado.Vida, 10);
    if (personajeActualizado.Nivel !== undefined) personajeActualizado.Nivel = parseInt(personajeActualizado.Nivel, 10);
    if (personajeActualizado.Fuerza !== undefined) personajeActualizado.Fuerza = parseInt(personajeActualizado.Fuerza, 10);
    if (personajeActualizado.Sabiduria !== undefined) personajeActualizado.Sabiduria = parseInt(personajeActualizado.Sabiduria, 10);
    if (personajeActualizado.Defensa !== undefined) personajeActualizado.Defensa = parseInt(personajeActualizado.Defensa, 10);

    localStorage.setItem("personajeSeleccionado", JSON.stringify(personajeActualizado));

    const listaJSON = localStorage.getItem("characters");
    if (listaJSON) {
        const listaPersonajes = JSON.parse(listaJSON);

        const indicePers = listaPersonajes.findIndex(p => {
            if (!p) return false;
            const nombreEnLista = p.Nombre || p._Nombre;
            const nombreActualizado = personajeActualizado.Nombre || personajeActualizado._Nombre;
            return nombreEnLista === nombreActualizado;
        });

        if (indicePers !== -1) {
            listaPersonajes[indicePers] = personajeActualizado;


            localStorage.setItem("characters", JSON.stringify(listaPersonajes));
        }
    }
}
function deleteCharacterUser(personaje) {
    var characters = getCharacters();
    var index = characters.findIndex(c =>
        c.Usuario === personaje.Usuario && c.Nombre === personaje.Nombre
    );
    if (index === -1) return false;

    characters.splice(index, 1);
    localStorage.setItem(CHAR_KEY, JSON.stringify(characters));

    var seleccionado = getSelectedCharacter();
    if (seleccionado && (seleccionado.Nombre || seleccionado._Nombre) === personaje.Nombre) {
        localStorage.removeItem("personajeSeleccionado");
    }
    return true;
}

function getPersonaje(id) {
    var personajes = localStorage.getItem(LOCAL_KEY);
    if (!personajes) return null;
    return JSON.parse(personajes)
        .map(obj => Personaje.fromJSON(obj))
        .find(x => x.id === id);
}

function getRankingUsers() {
    var rankingUser = localStorage.getItem(RANKING_KEY);
    if (!rankingUser) {
        return [];
    }
    return JSON.parse(rankingUser).map(obj => PersonajeRanking.fromJSON(obj));
}

function addCharacterToRanking(newCharacterRanking) {
    var lista = getRankingUsers().filter(r =>
        !(r.Usuario === newCharacterRanking.Usuario &&
          r.Nombre === newCharacterRanking.Nombre)
    );
    lista.push(newCharacterRanking);
    localStorage.setItem(RANKING_KEY, JSON.stringify(lista));
}

function removeRanking() {
    localStorage.removeItem(RANKING_KEY);
}

function refactorizarDato(personaje, contador){ //contador es nivel
    const usuario = personaje.Usuario || personaje._Usuario || UsuarioCargado().Nombre;
    const nombre  = personaje.Nombre  || personaje._Nombre;
    const imagen  = personaje.Imagen  || personaje._Imagen;

    const nuevo = new PersonajeRanking(usuario, nombre, imagen, Date.now(), contador);
    addCharacterToRanking(nuevo);
    
}