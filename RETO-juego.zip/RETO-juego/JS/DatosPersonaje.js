if (window.location.pathname.includes("personaje.html")) {
    window.addEventListener("load", () => {
        document.getElementById("cerrarVentana").addEventListener("click", () => {
            window.close();
        });
        renderizarFichaPersonaje();
    });
}

function renderizarFichaPersonaje() {
    const containerPersonajes = document.querySelector(".container_Personajes");
    const containerAcciones = document.querySelector(".container_Acciones");

    if (containerPersonajes) containerPersonajes.innerHTML = "";
    if (containerAcciones) containerAcciones.innerHTML = "";

    const personaje = getSelectedCharacter();

    if (!personaje) {
        if (containerPersonajes) containerPersonajes.textContent = "No hay ningún personaje seleccionado.";
        return;
    }

    const titulo = document.getElementById("personajeTitulo");
    if (titulo) {
        titulo.textContent = `Ficha de Personaje: ${personaje.Nombre}`;
    }

    generarTablaInfo(personaje);
    generarTablaAcciones(personaje);
}

function generarTablaInfo(pers) {
    if (!pers.Imagen) {
        pers.Imagen = imagenes[0];
        updateCharacter(pers);
    }

    const container = document.querySelector(".container_Personajes");
    const tabla = document.createElement("table");
    const header = document.createElement("thead");
    const filaHeader = document.createElement("tr");
    const thTitulo = document.createElement("th");

    thTitulo.textContent = "Información General";
    thTitulo.setAttribute("colspan", "2");
    filaHeader.appendChild(thTitulo);
    header.appendChild(filaHeader);
    tabla.appendChild(header);

    let imagen = document.createElement("img");
    imagen.src = pers.Imagen;
    imagen.alt = pers.Nombre;
    imagen.width = 150;
    imagen.height = 150;

    let indiceImagen = imagenes.indexOf(pers.Imagen);
    if (indiceImagen === -1) indiceImagen = 0;

    let botonImagen = document.createElement("button");
    botonImagen.textContent = "Cambiar imagen";
    botonImagen.addEventListener("click", () => {
        indiceImagen = (indiceImagen + 1) % imagenes.length;
        imagen.src = imagenes[indiceImagen];
        pers.Imagen = imagenes[indiceImagen];

        updateCharacter(pers);
    });

    container.appendChild(imagen);
    container.appendChild(botonImagen);

    const datos = {
        Nombre: pers.Nombre,
        Clase: pers.Clase,
        Nivel: pers.Nivel,
        Fuerza: pers.Fuerza,
        Sabiduria: pers.Sabiduria,
        Defensa: pers.Defensa,
        Vida: pers.Vida
    };

    for (const [etiqueta, valor] of Object.entries(datos)) {
        const fila = document.createElement("tr");
        const th = document.createElement("th");
        th.textContent = etiqueta;
        fila.appendChild(th);

        const td = document.createElement("td");
        td.textContent = valor;
        fila.appendChild(td);

        tabla.appendChild(fila);
    }
    container.appendChild(tabla);
}

function generarTablaAcciones(personaje) {
    const claseEncontrada = CLASES.find(c => c.nombre === personaje.Clase);
    if (!claseEncontrada) return;

    const tabla = document.createElement("table");
    const header = document.createElement("thead");
    const filaHeader = document.createElement("tr");
    const th = document.createElement("th");

    th.textContent = `Acciones de ${personaje.Nombre}`;
    th.setAttribute("colspan", "2");
    filaHeader.appendChild(th);
    header.appendChild(filaHeader);
    tabla.appendChild(header);

    for (const [nombreAccion, funcion] of Object.entries(claseEncontrada.acciones)) {
        const fila = document.createElement("tr");
        const accion = document.createElement("th");
        accion.textContent = nombreAccion.charAt(0).toUpperCase() + nombreAccion.slice(1);
        fila.appendChild(accion);

        const resultado = document.createElement("td");


        resultado.textContent = typeof funcion === "function" ? funcion(personaje) : funcion;
        fila.appendChild(resultado);

        tabla.appendChild(fila);
    }

    document.querySelector(".container_Acciones").appendChild(tabla);
}

const imagenes = [
    "../Multimedia/IMG/seleccion1.webp",
    "../Multimedia/IMG/seleccion2.png",
    "../Multimedia/IMG/seleccion3.webp",
    "../Multimedia/IMG/seleccion4.webp",
    "../Multimedia/IMG/seleccion5.webp",
    "../Multimedia/IMG/seleccion6.png"
];