var userNameButton = document.getElementById("fuser_mod");
userNameButton.addEventListener("click", function (e) {
    e.preventDefault();
    var userSession = UsuarioCargado();
    var nombreAntiguo = userSession.Nombre;
    var nuevoNombre = document.getElementById("fuser").value.trim();
    if (nuevoNombre === "" || nuevoNombre === nombreAntiguo) return;
    if (findUser(nuevoNombre)) {
        alert("Ese nombre de usuario ya existe");
        return;
    }
    if (updateUserName(nombreAntiguo, nuevoNombre)) {
        userSession.Nombre = nuevoNombre;
        saveSession(userSession);
        NombreDePaginaUser(nuevoNombre);
    }
});

var addCharacterButton = document.getElementById("btnAnadir");
addCharacterButton.addEventListener("click", function (e) {
    e.preventDefault();
    var characterName = prompt("Cual es el nombre del personaje?");
    var characterClass = prompt("Cual es la clase de este personaje?(Estas son las clases: " +
        "Guerrero, Mago, Arquero, Sacerdote, Picaro");
    if (characterName.trim() != "" || !characterName ) {
        if (!CLASES.some(c => c.nombre === characterClass)) {
            alert("No se seleccionó una clase válida");
            return;
        } else {
            var user = getSession();
            var newCharacter = new Personaje(
                user.Nombre, characterName.trim(), characterClass, 1, 10, 10, 10, 120, "../Multimedia/IMG/seleccion1.webp"
            );
            addCharacter(newCharacter);
            showCharacters(user);
        }
    } else {
        alert("El personaje debe tener un nombre completo");
    }
});

window.addEventListener("load", () => {
    var userSession = getSession();
    NombreDePaginaUser(userSession.Nombre);
    completarCampos(userSession);
    showCharacters(getSession());
});


function NombreDePaginaUser(user) {
    var userTitle = document.getElementById("userTitle");
    userTitle.innerHTML = "Perfil de " + user;
}

function completarCampos(user) {
    var userNameInput = document.getElementById("fuser");
    userNameInput.value = user.Nombre;
    var birthDateInput = document.getElementById("fcum");
    birthDateInput.value = user.FechaNacimiento;
    var ageInput = document.getElementById("fedad");
    ageInput.value = calcularEdad(user.FechaNacimiento);
}

function calcularEdad(fechaNacimiento) {
    return new Date().getFullYear() - new Date(fechaNacimiento).getFullYear();
}

function abrirDatosPersonaje(personaje) {
    localStorage.setItem("personajeSeleccionado", JSON.stringify(personaje));
    //no se puede implementar resizeable en navegadores que no sean internet explorer
    window.open("./personaje.html", "Personaje", "width=1000, height=500");
}

function showCharacters(user) {
    var lista = document.querySelector(".lista_personajes");
    lista.innerHTML = "";

    getCharacters().filter(c => c.Usuario === user.Nombre)
        .forEach(c => {
            var li = document.createElement("li");

            var texto = document.createElement("span");
            texto.textContent = c.Nombre + " (" + c.Clase + ") ";

            var btnInfo = document.createElement("button");
            btnInfo.type = "button";
            btnInfo.textContent = "Ver info";
            btnInfo.addEventListener("click", function () {
                abrirDatosPersonaje(c);
            });

            var btnDelete = document.createElement("button");
            btnDelete.type = "button";
            btnDelete.textContent = "Eliminar";
            btnDelete.addEventListener("click", function () {
                var confirmDelete = confirm("¿Seguro que quieres eliminar a " + c.Nombre + "?");
                if (confirmDelete){
                    if (deleteCharacterUser(c)) {
                        showCharacters(getSession());
                    }
                }
            });

            li.appendChild(texto);
            li.appendChild(btnInfo);
            li.appendChild(btnDelete);
            lista.appendChild(li);

        });
}

