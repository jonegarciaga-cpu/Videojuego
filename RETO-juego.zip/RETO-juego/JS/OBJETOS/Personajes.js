const CLASES = [
    {
        nombre: "Guerrero",
        acciones: {
            atacar: function () { return "¡Golpe de espada!"; },
            defender: function () { return "¡Escudo levantado!"; },
            esquivar: function () { return "¡Esquiva lateral!"; }
        }
    }, {
        nombre: "Mago",
        acciones: {
            atacar: function () { return "¡Bola de fuego!"; },
            defender: function () { return "¡Barrera mágica!"; },
            curar: function () { return "¡Poción de vida!"; }
        }
    }, {
        nombre: "Arquero",
        acciones: {
            atacar: function () { return "¡Flecha certera!"; },
            defender: function () { return "¡Cobertura!"; },
            disparoDoble: function () { return "¡Doble flecha!"; }
        }
    }, {
        nombre: "Sacerdote",
        acciones: {
            atacar: function () { return "¡Luz sagrada!"; },
            defender: function () { return "¡Bendición de protección!"; },
            curar: function () { return "¡Curación divina!"; }
        }
    }, {
        nombre: "Picaro",
        acciones: {
            atacar: function () { return "¡Golpe sigiloso!"; },
            defender: function () { return "¡Humo de escape!"; },
            ataquefurtivo: function () { return "¡Golpe critico asegurado!"; }
        }
    }
];

class Personaje {
    constructor(Usuario, Nombre, Clase, Nivel, Fuerza, Sabiduria, Defensa, Vida, Imagen) {
        this._Usuario = Usuario;
        this._Nombre = Nombre;
        this._Clase = Clase;
        this._Nivel = Nivel;
        this._Fuerza = Fuerza;
        this._Sabiduria = Sabiduria;
        this._Defensa = Defensa;
        this._Vida = Vida;
        this._Imagen = Imagen;
    }

    get Usuario() { return this._Usuario; }
    set Usuario(valor) {
        if (typeof valor !== "string") throw new Error("Debe ser string");
        this._Usuario = valor;
    }

    get Nombre() { return this._Nombre; }
    set Nombre(valor) {
        if (typeof valor !== "string") throw new Error("Debe ser string");
        this._Nombre = valor;
    }

    get Clase() { return this._Clase; }
    set Clase(nombre) {
        const encontrada = CLASES.find(c => c.nombre === nombre);
        if (!encontrada) throw new Error("Clase no válida");
        this._Clase = nombre;  
    }

    get Nivel() { return this._Nivel; }
    set Nivel(valor) {
        if (typeof valor !== "number" || valor < 1) throw new Error("Debe ser un numero");
        this._Nivel = valor;
    }

    get Fuerza() { return this._Fuerza; }
    set Fuerza(valor) {
        if (typeof valor !== "number") throw new Error("Debe ser un numero <10 como las que le gustana dani");
        this._Fuerza = valor;
    }

    get Sabiduria() { return this._Sabiduria; }
    set Sabiduria(valor) {
        if (typeof valor !== "number") throw new Error("Debe ser un numero");
        this._Sabiduria = valor;
    }

    get Defensa() { return this._Defensa; }
    set Defensa(valor) {
        if (typeof valor !== "number") throw new Error("Debe ser un numero");
        this._Defensa = valor;
    }

    get Vida() { return this._Vida; }
    set Vida(valor) {
        if (typeof valor !== "number") throw new Error("Debe ser un numero");
        this._Vida = valor;
    }

    get Imagen() { return this._Imagen; }
    set Imagen(valor) {
        if (typeof valor !== "string") throw new Error("Debe ser string");
        this._Imagen = valor;
    }

    toJSON() {
        return {
            Usuario: this._Usuario,
            Nombre: this._Nombre,
            Clase: this._Clase,
            Nivel: this._Nivel,
            Fuerza: this._Fuerza,
            Sabiduria: this._Sabiduria,
            Defensa: this._Defensa,
            Vida: this._Vida,
            Imagen: this._Imagen
        };
    }

    static fromJSON(obj) {
        return new Personaje(obj.Usuario, obj.Nombre, obj.Clase, obj.Nivel,
            obj.Fuerza, obj.Sabiduria, obj.Defensa, obj.Vida, obj.Imagen);
    }
}

