class PersonajeRanking {
    constructor(Usuario, Nombre, Imagen, FechaHora, Puntuacion) {
        this._Usuario = Usuario;
        this._Nombre = Nombre;
        this._Imagen = Imagen;
        this._FechaHora = FechaHora;
        this._Puntuacion = Puntuacion; //Rondas
    }
    
    get Usuario() { return this._Usuario; }
    set Usuario(valor) {
        if (typeof valor !== "string") throw new Error("Debe ser string");
        this._Usuario = valor;
    }

    get Nombre() { return this._Nombre; }
    set Nombre(valor) {
        if (typeof valor !== "string") throw new Error("Debe ser string");
        this._Nombre = valor;
    }

    get Imagen() { return this._Imagen; }
    set Imagen(valor) {
        if (typeof valor !== "string") throw new Error("Debe ser string");
        this._Imagen = valor;
    }

    get FechaHora() { return this._FechaHora; }
    set FechaHora(valor) {
        if (typeof valor !== "number") throw new Error("Debe ser un numero");
        this._FechaHora = valor;
    }

    get Puntuacion() { return this._Puntuacion; }
    set Puntuacion(valor) {
        if (typeof valor !== "number" || valor < 1) throw new Error("Debe ser un numero");
        this._Puntuacion = valor;
    }

    toJSON() {
    return {
        Usuario: this._Usuario,
        Nombre: this._Nombre,
        Imagen: this._Imagen,
        FechaHora: this._FechaHora,
        Puntuacion: this._Puntuacion
    };
}

static fromJSON(obj) {
    return new PersonajeRanking(obj.Usuario, obj.Nombre, obj.Imagen,
        obj.FechaHora, obj.Puntuacion);
}
}