class User {
    constructor(Nombre, Contraseña, FechaNacimiento, Genero, Existes) {
        this.Nombre = Nombre;
        this.Contraseña = Contraseña;
        this.FechaNacimiento = FechaNacimiento;
        this.Genero = Genero;
        this.Existes = Existes; //El jugador ha jugado antes
    }

    get Nombre() { return this._Nombre; }
    set Nombre(valor) {
        if (typeof valor !== "string") throw new Error("Debe ser string");
        this._Nombre = valor;
    }

    get Contraseña() { return this._Contraseña; }
    set Contraseña(valor) {
        if (typeof valor !== "string") throw new Error("Debe ser string");
        this._Contraseña = valor;
    }

    get FechaNacimiento() { return this._FechaNacimiento; }
    set FechaNacimiento(valor) {
        if (typeof valor !== "string") throw new Error("Debe ser una fecha en formato texto");
        this._FechaNacimiento = valor;
    }

    get Genero() { return this._Genero; }
    set Genero(valor) {
        if (valor !== "H" && valor !== "M") throw new Error("Debe ser H o M");
        this._Genero = valor;
    }

    get Existes() { return this._Existes; }
    set Existes(valor) {
        if (typeof valor !== "boolean") throw new Error("Debe ser true o false");
        this._Existes = valor;
    }

    toJSON() {
        return {
            Nombre: this._Nombre,
            Contraseña: this._Contraseña,
            FechaNacimiento: this._FechaNacimiento,
            Genero: this._Genero,
            Existes: this._Existes
        };
    }

    static fromJSON(obj) {
        return new User(obj.Nombre, obj.Contraseña, obj.FechaNacimiento, obj.Genero, obj.Existes);
    }
}