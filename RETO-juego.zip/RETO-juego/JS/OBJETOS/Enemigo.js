class Enemigo {
    constructor(Nombre, Nivel, Fuerza, Defensa, Vida, Imagen) {
        this._Nombre = Nombre;
        this._Nivel = Nivel;
        this._Fuerza = Fuerza;
        this._Defensa = Defensa;
        this._Vida = Vida;
        this._Imagen = Imagen;
    }

    get Nombre() { return this._Nombre; }
    set Nombre(valor) {
        if (typeof valor !== "string") throw new Error("Debe ser string");
        this._Nombre = valor;
    }

    get Clase() { return this._Clase; }
    set Clase(nombre) {
        const encontrada = this._Clase.find(c => c.nombre === nombre);
        if (!encontrada) throw new Error("Clase no válida");
        this._ClaseActual = encontrada;
    }

    get Nivel() { return this._Nivel; }
    set Nivel(valor) {
        if (typeof valor !== "number" || valor < 10) throw new Error("Debe ser un numero");
        this._Nivel = valor;
    }

    get Fuerza() { return this._Fuerza; }
    set Fuerza(valor) {
        if (typeof valor !== "number") throw new Error("Debe ser un numero <10 como las que le gustana dani");
        this._Fuerza = valor;
    }

    get Defensa() { return this._Defensa; }
    set Defensa(valor) {
        if (typeof valor !== "number") throw new Error("Debe ser un numero");
        this._Defensa = valor;
    }

    get Vida() { return this._Vida; }
    set Vida(valor) {
        if (typeof valor !== "number") throw new Error("Debe ser un numero");
        this._Vida = valor;
    }

    get Imagen() { return this._Imagen; }
    set Imagen(valor) {
        if (typeof valor !== "string") throw new Error("Debe ser string");
        this._Imagen = valor;
    }
}
const Enemigos = [];

const goblin = new Enemigo("Goblin", 1, 10, 10, 100, "../Multimedia/IMG/Enemigo_Goblin.webp");
Enemigos.push(goblin);

const hobgoblin = new Enemigo("Hobgoblin", 1, 15, 15, 150, "../Multimedia/IMG/Enemigo_Hobgoblin.webp");
Enemigos.push(hobgoblin);

const orco = new Enemigo("Orco", 1, 20, 20, 200, "../Multimedia/IMG/Enemigo_Orco.webp");
Enemigos.push(orco);