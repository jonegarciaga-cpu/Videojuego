let contador = 0; let contadorActual = null;
let imagenJugadorActual = null; let jugadorMuerto = false;
let maxVidaJugador; let maxVidaEnemigoActual;

function obtenerIndiceEnemigoActual() {
    let posicionEnCiclo = contador % 10;
    let indice = 0;

    if (contador === 0) {
        indice = 0;
    } else if (posicionEnCiclo === 5) {
        indice = 1;
    } else if (posicionEnCiclo === 0) {
        indice = 2;
    }

    return indice;
}

function alElegirEnemigoActual() {
    const idx = obtenerIndiceEnemigoActual();
    const factorEscalado = 25;
    maxVidaEnemigoActual = Enemigos[idx].Vida + (contador * factorEscalado);
}

function alElegirPersonaje() {
    const p = PersonajeElegido();
    if (p) {
        p.Vida = parseInt(p.Vida, 10);
        maxVidaJugador = p.Vida;
    }
    sessionStorage.setItem("personajeElegido", JSON.stringify(p));
}

window.addEventListener("load", () => {
    InicializarPersonaje();
    if (personajeSeleccionado === null) return;

    if (personajeSeleccionado.Nivel === 10) {
        irPantallaFinal();
        window.location.href = "./perfil.html"; window.close();
        return;
    }

    alElegirPersonaje();
    alElegirEnemigoActual();
    generarBarra("vida_jugador", 100);
    generarBarra("vida_enemigo", 100);

    NombreDePaginaJuego(UsuarioCargado().Nombre);
    mostrarPersonaje();
    mostrarEnemigo(0);

    CrearListaPersonajes(UsuarioCargado());
    CrearListaAtaques(PersonajeElegido());

    document.getElementById("IconoJuego").addEventListener("click", lanzarDado);

    document.querySelectorAll('#vertedero_lista .header').forEach(header => {
        header.addEventListener('click', () => {
            header.parentElement.classList.toggle('open');
        });
    });

    document.getElementById("zona_ataque").addEventListener("click", (e) => {
        actualizarBarraJugador(dañoPersonaje(Enemigos));
        actualizarBarraEnemigo(dañoEnemigo(PersonajeElegido()));
        textoAtaque(e);
    });

    document.getElementById("zona_ataque").addEventListener("contextmenu", (e) => {
        e.preventDefault();
        const daño = defensaPersonaje(PersonajeElegido(), Enemigos);
        actualizarBarraJugador(daño);
        if (daño > 0) animarGolpe('jugador');
        textoDefensa(e);
    });
});

function textoAtaque(e) {
    const texto = document.createElement("span");
    const clase = CLASES.find(c => c.nombre === PersonajeElegido()._Clase);
    const resultado = clase.acciones.atacar();
    const color = "red";
    textoflotante(e, texto, resultado, color)
}

function textoDefensa(e) {
    const texto = document.createElement("span");
    const clase = CLASES.find(c => c.nombre === PersonajeElegido()._Clase);
    const resultado = clase.acciones.defender();
    const color = "green";
    textoflotante(e, texto, resultado, color)
}

function textoflotante(e, texto, resultado, color) {
    texto.textContent = resultado;
    texto.style.position = "fixed";
    texto.style.left = e.clientX + "px";
    texto.style.top = e.clientY + "px";
    texto.style.color = color;
    document.body.appendChild(texto);
    setTimeout(() => texto.remove(), 1000);
}

function defensaPersonaje(personaje, Enemigos) {
    const idx = obtenerIndiceEnemigoActual();
    var daño = Enemigos[idx].Fuerza;
    var defensa = personaje.Defensa;
    if (defensa < daño) {
        return daño - defensa;
    } return 0;
}

function dañoEnemigo(personaje) {
    var daño;
    if (personaje.clase === "Mago" || personaje.clase === "Sacerdote") {
        daño = personaje.Sabiduria;
    } else {
        daño = personaje.Fuerza;
    }
    return formuladaño(daño);
}

function dañoPersonaje(Enemigos) {
    const idx = obtenerIndiceEnemigoActual();
    var daño = Enemigos[idx].Fuerza + contador;
    return formuladaño(daño);
}

function formuladaño(daño) {
    if (Math.random() < 0.05) {
        return daño * 2
    } return daño;
}

function animarGolpe(idElemento) {
    const elemento = document.getElementById(idElemento);
    elemento.classList.remove('hit');
    void elemento.offsetWidth;
    elemento.classList.add('hit');
    elemento.addEventListener('animationend', () => elemento.classList.remove('hit'), { once: true });
}

function NombreDePaginaJuego(user) {
    var juegoTitle = document.getElementById("juegoTitle");
    juegoTitle.innerHTML = "Las maravillosas aventuras de " + user;
}

function generarBarra(id, porcentaje) {
    const barra = document.getElementById(id);
    barra.style.width = porcentaje + "%";
    barra.textContent = porcentaje + "%";
}

function actualizarBarraVida(vidamax, eOp, elemento, daño, onMuerte) {
    eOp.Vida = Math.max(0, eOp.Vida - daño);
    const pct = (eOp.Vida / vidamax * 100);
    const id = document.getElementById(elemento);
    id.style.width = pct + "%";
    id.textContent = Math.round(pct) + "%";
    return eOp.Vida;
}

function actualizarBarraJugador(daño) {
    if (actualizarBarraVida(maxVidaJugador, PersonajeElegido(), "vida_jugador", daño) === 0) {
        PersonajeElegido().Vida = maxVidaJugador;
        muerteJugador(PersonajeElegido());
    }
}

function actualizarBarraEnemigo(daño) {
        const idx = obtenerIndiceEnemigoActual();
    
    if (Enemigos[idx].Vida_Actual === undefined || Enemigos[idx].Vida_Actual === null) {
        Enemigos[idx].Vida_Actual = maxVidaEnemigoActual;
    }
    
    let enemigoTemporal = { Vida: Enemigos[idx].Vida_Actual };
    
    let vidaRestante = actualizarBarraVida(maxVidaEnemigoActual, enemigoTemporal, "vida_enemigo", daño);
    
    Enemigos[idx].Vida_Actual = vidaRestante;

    if (vidaRestante === 0) {
        Enemigos[idx].Vida_Actual = null; 
        muerteEnemiga(Enemigos[idx]);
    }

}

function muerteJugador(p) {
    if (jugadorMuerto) return;
    jugadorMuerto = true;
    console.log("JugadorMuerto");
    reproducirAudio("../Multimedia/Audio/Prueba.mp3");
    refactorizarDato(PersonajeElegido(), contador);
    irPantallaFinal();
    
}
function irPantallaFinal() {
    window.open("./gameOver.html", "GAME OVER", "width=1000, height=500");
}

function muerteEnemiga(e) {
    contador++;
    if (contador % 2 === 0 || contador % 10 === 1) {
        if (contador < 10) {
            PersonajeElegido().Vida = maxVidaJugador;
        } else {
            PersonajeElegido().Vida += maxVidaJugador / 2;

            if (PersonajeElegido().Vida > maxVidaJugador) {
                PersonajeElegido().Vida = maxVidaJugador;
            }
        }
        generarBarra("vida_jugador", Math.round((PersonajeElegido().Vida / maxVidaJugador) * 100));
    }
    subirNivel();
    alElegirEnemigoActual();
    mostrarEnemigo(obtenerIndiceEnemigoActual());
    generarBarra("vida_enemigo", 100);
    mostrarContador(contadorActual);
    reproducirAudio("../Multimedia/Audio/Prueba.mp3");
}

function mostrarContador() {
    const contenedorcontador = document.getElementById("contador");
    if (contadorActual) { contadorActual.remove(); }
    const c = document.createElement("span");
    contenedorcontador.appendChild(c);

    c.textContent = contador;
    c.id = "NumeroContador";
    contadorActual = c;
}

function mostrarPersonaje() {
    console.log("JugadorRevivido");
    contador = 0;
    jugadorMuerto = false;

    const personaje = PersonajeElegido();
    personaje.Vida = maxVidaJugador;

    if (imagenJugadorActual) { imagenJugadorActual.remove(); }

    generarBarra("vida_enemigo", 100);
    generarBarra("vida_jugador", 100);

    const jugador = document.getElementById("jugador");
    const imagenJugador = document.createElement("img");

    imagenJugador.src = personaje._Imagen;
    imagenJugador.alt = personaje._Nombre;

    jugador.insertBefore(imagenJugador, jugador.firstChild);
    imagenJugadorActual = imagenJugador;
}

function mostrarEnemigo(numero) {
    const enemigo = document.getElementById("enemigo");
    const imagenPrevia = enemigo.querySelector("img");
    if (imagenPrevia) {
        imagenPrevia.remove();
    }
    const infoEnemigo = Enemigos[numero];
    const imagenEnemigo = document.createElement("img");
    imagenEnemigo.src = infoEnemigo.Imagen;
    imagenEnemigo.alt = infoEnemigo.Nombre;

    enemigo.insertBefore(imagenEnemigo, enemigo.firstChild);
}

function reproducirAudio(ruta) {
    const audio = new Audio(ruta);
    audio.play().catch(() => { });
}

function lanzarDado() {
    const escena = document.getElementById("escena_dado");
    const wrapper = document.getElementById("wrapper");
    const die = document.getElementById("die");
    const DROP_MS = 1400;

    if (wrapper.classList.contains("dropping")) { return; }    // Evitar lanzar mientras está cayendo

    escena.style.display = "block";    // Mostrar dado

    // Reiniciar animaciones
    wrapper.classList.remove("dropping");
    die.classList.remove("rolling");
    die.removeAttribute("data-face");

    void wrapper.offsetWidth;

    // Lanzar dado
    wrapper.classList.add("dropping");
    die.classList.add("rolling");

    setTimeout(() => {
        const face = Math.floor(Math.random() * 20) + 1;
        reproducirAudio("../Multimedia/Audio/Prueba.mp3");

        die.classList.remove("rolling");
        die.setAttribute("data-face", face);

        setTimeout(() => {
            escena.style.display = "none";
            wrapper.classList.remove("dropping");
            die.removeAttribute("data-face");
        }, 2000);
    }, DROP_MS);
}

function subirNivel() {
    const personaje = PersonajeElegido();
    maxVidaJugador = parseInt(maxVidaJugador, 10);

    if (personaje && personaje.Nivel < 10) {
        switch (personaje.Clase.toLowerCase()) {
            case 'guerrero': subirGuerrero(personaje); break;
            case 'mago': subirMago(personaje); break;
            case 'arquero': subirArquero(personaje); break;
            case 'sacerdote': subirSacerdote(personaje); break;
            case 'picaro': subirPicaro(personaje); break;
            default: console.log("Clase no reconocida");
        }
    }
}
function subirGuerrero(personaje) {
    if (personaje.Nivel != 5) {
        personaje.Nivel += 1; personaje.Fuerza += 1;
        personaje.Sabiduria += 1; personaje.Defensa += 2;
        maxVidaJugador += 30;
    } else {
        personaje.Nivel += 1; personaje.Fuerza += 2;
        personaje.Sabiduria += 2; personaje.Defensa += 3;
        maxVidaJugador += 40;
    }
    finalizarSubidaNivel(personaje);
}

function subirMago(personaje) {
    if (personaje.Nivel != 5) {
        personaje.Nivel += 1; personaje.Fuerza += 1;
        personaje.Sabiduria += 4; personaje.Defensa += 2;
        maxVidaJugador += 20;
    } else {
        personaje.Nivel += 1; personaje.Fuerza += 2;
        personaje.Sabiduria += 5; personaje.Defensa += 3;
        maxVidaJugador += 20;
    }
    finalizarSubidaNivel(personaje);
}

function subirArquero(personaje) {
    if (personaje.Nivel != 5) {
        personaje.Nivel += 1; personaje.Fuerza += 3;
        personaje.Sabiduria += 1; personaje.Defensa += 2;
        maxVidaJugador += 10;
    } else {
        personaje.Nivel += 1; personaje.Fuerza += 4;
        personaje.Sabiduria += 2; personaje.Defensa += 3;
        maxVidaJugador += 20;
    }
    finalizarSubidaNivel(personaje);
}

function subirSacerdote(personaje) {
    if (personaje.Nivel != 5) {
        personaje.Nivel += 1; personaje.Fuerza += 1;
        personaje.Sabiduria += 2; personaje.Defensa += 1;
        maxVidaJugador += 30;
    } else {
        personaje.Nivel += 1; personaje.Fuerza += 2;
        personaje.Sabiduria += 3; personaje.Defensa += 2;
        maxVidaJugador += 40;
    }
    finalizarSubidaNivel(personaje);
}

function subirPicaro(personaje) {
    if (personaje.Nivel != 5) {
        personaje.Nivel += 1; personaje.Fuerza += 2;
        personaje.Sabiduria += 1; personaje.Defensa += 1;
        maxVidaJugador += 20;
    } else {
        personaje.Nivel += 1; personaje.Fuerza += 3;
        personaje.Sabiduria += 2; personaje.Defensa += 2;
        maxVidaJugador += 30;
    }
    finalizarSubidaNivel(personaje);
}
function finalizarSubidaNivel(personaje) {
    let eleccion = "";

    while (
        eleccion !== "fuerza" && eleccion !== "1" &&
        eleccion !== "sabiduria" && eleccion !== "2" &&
        eleccion !== "defensa" && eleccion !== "3" &&
        eleccion !== "vida" && eleccion !== "4"
    ) {
        eleccion = prompt(
            "¡Has subido de nivel! Elige una estadística para otorgarle un punto/bonus extra:\n" +
            "1. Fuerza\n" +
            "2. Sabiduria\n" +
            "3. Defensa\n" +
            "4. Vida"
        );

        if (eleccion === null) {
            eleccion = "vida";
        } else {
            eleccion = eleccion.toLowerCase().trim();
        }
    }

    const bonusAleatorio = Math.floor(Math.random() * 4) + 1;

    switch (eleccion) {
        case 'fuerza':
        case '1':
            personaje.Fuerza += bonusAleatorio;
            alert("Fuerza aumentada en +" + bonusAleatorio);
            break;
        case 'sabiduria':
        case '2':
            personaje.Sabiduria += bonusAleatorio;
            alert("Sabiduría aumentada en +" + bonusAleatorio);
            break;
        case 'defensa':
        case '3':
            personaje.Defensa += bonusAleatorio;
            alert("Defensa aumentada en +" + bonusAleatorio);
            break;
        case 'vida':
        case '4':
            const bonusVida = bonusAleatorio * 10;
            maxVidaJugador += bonusVida;
            alert("Vida máxima aumentada en +" + bonusVida);
            break;
    }

    personaje.Vida = maxVidaJugador;
    console.log("Se ha subido al nivel: " + personaje.Nivel + ". Fuerza: " + personaje.Fuerza + ". Sabiduria: " + personaje.Sabiduria + ". Defensa: " + personaje.Defensa + ". Vida: " + maxVidaJugador);
    updateCharacter(personaje);
}