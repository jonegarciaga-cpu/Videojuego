let personajeSeleccionado = null;
const linkJuego = document.querySelector('a[href="./juego.html"]');

function InicializarPersonaje() {
    const personajes = getCharacters().filter(c => c.Usuario === UsuarioCargado().Nombre);
    if (personajes.length > 0) {
        personajeSeleccionado = personajes[0];
    } else {
        personajeSeleccionado = null;
    }
    ActualizarLinkJuego();
    if (personajeSeleccionado === null) {
        goToPerfil();
    }
}

function goToPerfil() {
    alert("Necesitas tener un personaje para acceder a esta parte del juego.");
    window.location.href = "./perfil.html";
}

function SeleccionarPersonaje(personaje) {
    personajeSeleccionado = personaje;
    ActualizarLinkJuego();
}

function ActualizarLinkJuego() {
    if (linkJuego) {
        if (personajeSeleccionado === null) {
            linkJuego.style.pointerEvents = "none";
            linkJuego.style.opacity = "0.4";
            linkJuego.title = "Debes tener un personaje primero";
            linkJuego.href = "";
        } else {
            linkJuego.href = "./juego.html";
        }
    }
}

function PersonajeElegido() {
    return personajeSeleccionado;
}

function UsuarioCargado() {
    return getSession();
}

function CrearListaPersonajes(usuario) {
    const lista_personajes = document.getElementById("contenido_personaje");
    lista_personajes.innerHTML = ""; // limpiar antes de rellener

    const h6Personaje = document.createElement("h6");
    lista_personajes.appendChild(h6Personaje);
    const ulPersonaje = document.createElement("ul");
    lista_personajes.appendChild(ulPersonaje);

    ContenidoListaPersonaje(ulPersonaje, usuario);
}

function ContenidoListaPersonaje(ul, user) {
    getCharacters().filter(p => p.Usuario === user.Nombre)
        .forEach(p => AñadirPersonajeNombre(p, ul));
}

function AñadirPersonajeNombre(p, ul) {
    const li = document.createElement("li");
    li.textContent = p.Nombre;

    li.addEventListener("click", () => {
        p.Vida = parseInt(p.Vida, 10);
        p.Nivel = parseInt(p.Nivel, 10);
        p.Fuerza = parseInt(p.Fuerza, 10);
        p.Sabiduria = parseInt(p.Sabiduria, 10);
        p.Defensa = parseInt(p.Defensa, 10);

        personajeSeleccionado = p;
        maxVidaJugador = p.Vida;

        sessionStorage.setItem("personajeElegido", JSON.stringify(p));

        CrearListaAtaques(p);
        mostrarPersonaje();
    });

    ul.appendChild(li);
}

function CrearListaAtaques(personaje) {
    const lista_ataques = document.getElementById("contenido_ataques");
    lista_ataques.innerHTML = ""; // limpiar antes de rellener

    const h5Ataque = document.createElement("h5");
    lista_ataques.appendChild(h5Ataque);
    const h6Ataque = document.createElement("h6");
    lista_ataques.appendChild(h6Ataque);
    const ulAtaque = document.createElement("ul");
    lista_ataques.appendChild(ulAtaque);

    ContenidoListaAtaque(ulAtaque, personaje);
}

function ContenidoListaAtaque(ul, personaje) {
    const clase = CLASES.find(c => c.nombre === personaje.Clase);
    for (const [nombreAccion, funcion] of Object.entries(clase.acciones)) {
        const li = document.createElement("li");
        li.textContent = funcion();
        ul.appendChild(li);
    }
}

function AñadirPersonajeAtaque(personaje, ul) {
    const li = document.createElement("li");
    const clase = CLASES.find(c => c.nombre === personaje.Clase);
    li.textContent = clase.acciones.atacar();
    ul.appendChild(li);
}

document.addEventListener("DOMContentLoaded", function () {
    const logOutButton = document.getElementById("logOut");
    if (logOutButton) {
        logOutButton.addEventListener("click", function (e) {
            e.preventDefault();
            closeSession();
            window.location.href = "../index.html";
        });
    }
});


